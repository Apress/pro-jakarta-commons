package com.commonsbook.chap7;
import org.apache.commons.digester.Digester;

import java.util.Vector;

public class DigestStudents {
    Vector students;

    public DigestStudents() {
        students = new Vector();
    }

    public static void main(String[] args) {
        DigestStudents digestStudents = new DigestStudents();
        digestStudents.digest();
    }

    private void digest() {
        try {
            Digester digester = new Digester();

            //Push the current object on to the stack
            digester.push(this);

            //Creates a new instance of the Student class
            digester.addObjectCreate("students/student", Student.class);

            //Uses setName method of the Student instance.
            //Uses tag name as the property name
            digester.addBeanPropertySetter("students/student/name");

            //Uses setCourse method of the Student instance.
            //Explicitly specify property name as 'course'
            digester.addBeanPropertySetter("students/student/course", "course");

            //Move to next student
            digester.addSetNext("students/student", "addStudent");

            DigestStudents ds = (DigestStudents) digester.parse(this.getClass()
                                .getClassLoader()
                                .getResourceAsStream("students.xml"));

            //Print the contents of the Vector
            System.out.println("Students Vector " + ds.students);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void addStudent(Student stud) {
        //Add a new Student instance to the Vector
        students.add(stud);
    }
}
