package com.commonsbook.chap7.academy;
import org.apache.commons.beanutils.PropertyUtils;

import java.util.Vector;

public class Teacher {
    private String name;
    private Vector certifications;

    public Teacher() {
        certifications = new Vector();
    }

    public void addCertification(String certification) {
        certifications.addElement(certification);
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public void setCertifications(Vector certifications) {
        this.certifications = certifications;
    }

    public Vector getCertifications() {
        return certifications;
    }

    public String toString() {
        StringBuffer buf = new StringBuffer(60);
        buf.append("\nTeacher name>> " + this.getName());

        Vector certs = this.getCertifications();

        //Iterate through vector. Append content to StringBuffer.
        for (int i = 0; i < certs.size(); i++) {
            buf.append("\n\tCertification>> " + certs.get(i));
        }

        return buf.toString();
    }
}
