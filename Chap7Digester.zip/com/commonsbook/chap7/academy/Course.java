package com.commonsbook.chap7.academy;
import org.apache.commons.beanutils.PropertyUtils;

import java.util.Vector;

public class Course {
    private String id;
    private String name;

    public Course() {
    }

    public String getId() {
        return id;
    }

    public void setId(String newId) {
        id = newId;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String toString() {
        StringBuffer buf = new StringBuffer(60);
        buf.append("\n\tCourseId>>> " + this.getId() + "\t");
        buf.append("CourseName>>> " + this.getName());

        return buf.toString();
    }
}
