package com.commonsbook.chap7.academy;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.digester.Digester;

import java.util.Vector;

public class DigestJavaAcademy {
    public static void main(String[] args) throws Exception {
        DigestJavaAcademy d = new DigestJavaAcademy();
        d.digest();
    }

    public void digest() throws Exception {
        Digester digester = new Digester();
        digester.addObjectCreate("academy", Academy.class);

        //Set the attribute values as properties
        digester.addSetProperties("academy");

        //A new Student instance for the student tag
        digester.addObjectCreate("academy/student", Student.class);

        //Set the attribute values as properties
        digester.addSetProperties("academy/student");

        //A new Course instance
        digester.addObjectCreate("academy/student/course", Course.class);

        //Set properties of the Course instance with values of two child tags.
        digester.addBeanPropertySetter("academy/student/course/id", "id");
        digester.addBeanPropertySetter("academy/student/course/name", "name");

        //Next Course
        digester.addSetNext("academy/student/course", "addCourse");

        //Next student
        digester.addSetNext("academy/student", "addStudent");

        //A new instance of Teacher
        digester.addObjectCreate("academy/teacher", Teacher.class);

        ///Set teacher name with attribute value
        digester.addSetProperties("academy/teacher");

        //Call Method addCertification that takes a single parameter
        digester.addCallMethod("academy/teacher/certification",
            "addCertification", 1);

        //Set value of the parameter for the addCertification method
        digester.addCallParam("academy/teacher/certification", 0);

        //Next Teacher
        digester.addSetNext("academy/teacher", "addTeacher");

        //Parse the XML file to get an Academy instance
        Academy a = (Academy) digester.parse(this.getClass().getClassLoader()
                                              .getResourceAsStream("academy.xml"));

        //Get Academy Details. Use overriden toString methods
        System.out.println(a);
    }
}
