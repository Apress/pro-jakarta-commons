package com.commonsbook.chap7.academy;
import org.apache.commons.beanutils.PropertyUtils;

import java.util.Vector;

public class Academy {
    private Vector students;
    private Vector teachers;
    private String name;

    public Academy() {
        students = new Vector();
        teachers = new Vector();
    }

    public void addStudent(Student student) {
        students.addElement(student);
    }

    public void addTeacher(Teacher teacher) {
        teachers.addElement(teacher);
    }

    public Vector getStudents() {
        return students;
    }

    public void setStudents(Vector newStudents) {
        students = newStudents;
    }

    public Vector getTeachers() {
        return teachers;
    }

    public void setTeachers(Vector newTeachers) {
        teachers = newTeachers;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String toString() {
        StringBuffer buf = new StringBuffer(60);

        buf.append("Academy name>> " + this.getName());

        Vector stud = this.getStudents();
        Vector teach = this.getTeachers();
        buf.append("\n\n**STUDENTS**");

        //Iterate through vectors. Append content to StringBuffer.
        for (int i = 0; i < stud.size(); i++) {
            buf.append(stud.get(i));
        }

        buf.append("\n\n**TEACHERS**");

        for (int i = 0; i < teach.size(); i++) {
            buf.append(teach.get(i));
        }

        return buf.toString();
    }
}
