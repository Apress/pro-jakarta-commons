package com.commonsbook.chap7;
public class Student {
    private String name;
    private String course;

    public Student() {
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String newCourse) {
        course = newCourse;
    }

    public String toString() {
        return ("Name=" + this.name + " & Course=" + this.course);
    }
}
