package com.commonsbook.chap8;
import org.apache.commons.collections.BeanMap;

public class BeanMapTrial {
    public static void main(String[] args) {
        Human one = new Human();
        one.setAge(100);
        one.setName("Anonymous");

        BeanMap humanBeanMap = new BeanMap(one);
        System.out.println("Name Type >>" + humanBeanMap.getType("name"));
        System.out.println("Name Class >>" +humanBeanMap.get("name").getClass());
        System.out.println("Name Value >>" + humanBeanMap.get("name"));

        System.out.println("Age Type >>" + humanBeanMap.getType("age"));
        System.out.println("Age Class >>" + humanBeanMap.get("age").getClass());
        System.out.println("Age Value >>" + humanBeanMap.get("age"));
    }
}
