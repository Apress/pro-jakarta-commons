package com.commonsbook.chap8;
import java.util.Comparator;

public class HumanComparator implements Comparator {
    public int compare(Object humanOne, Object humanTwo) {
        if (!(humanOne instanceof Human) || !(humanTwo instanceof Human)) {
            throw new ClassCastException("A Human object expected.");
        }

        int diff = ((Human) humanOne).getAge() - ((Human) humanTwo).getAge();

        return diff;
    }
}
