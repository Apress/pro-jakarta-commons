package com.commonsbook.chap8;
import org.apache.commons.collections.MapIterator;
import org.apache.commons.collections.bidimap.TreeBidiMap;

public class TreeBidiMapTrial {
    public static void main(String[] args) {
        TreeBidiMap tbm = new TreeBidiMap();
        tbm.put("KEY1", "VALUE1");
        tbm.put("KEY2", "VALUE2");

        System.out.println("Value for KEY2 >>" + tbm.get("KEY2"));
        System.out.println("Key for VALUE2 >>" + tbm.getKey("VALUE2"));

        System.out.println("***Iterate over Map***");

        MapIterator it = tbm.mapIterator();

        while (it.hasNext()) {
            System.out.println("Key=" + it.next() + "\nVal=" + it.getValue());
        }
    }
}
