package com.commonsbook.chap8;
import org.apache.commons.collections.ArrayStack;

import java.util.Iterator;

public class ArrayStackTrial {
    public static void main(String[] args) {
        ArrayStack aStack = new ArrayStack();
        aStack.add("STOne");
        aStack.add("STTwo");
        aStack.add("STThree");

        Iterator stackItr = aStack.iterator();

        while (stackItr.hasNext()) {
            System.out.println("**" + stackItr.next());
        }

        System.out.println(">>" + aStack.remove());
        System.out.println(">>" + aStack.remove());
        System.out.println(">>" + aStack.remove());
    }
}
