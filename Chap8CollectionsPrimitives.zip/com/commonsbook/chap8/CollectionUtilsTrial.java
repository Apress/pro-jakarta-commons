package com.commonsbook.chap8;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CollectionUtilsTrial {
    public static void main(String[] args) {
        ArrayList integerList = new ArrayList();
        integerList.add(new Integer(10));
        integerList.add(new Integer(11));
        integerList.add(new Integer(12));

        System.out.println("Old >>" + integerList);

        Collection incrementedList = CollectionUtils.collect(integerList,
                new TenPlusTransformer());
        System.out.println("Transformed >>" + incrementedList);
    }
}


class TenPlusTransformer implements Transformer {
    public Object transform(Object input) {
        if (!(input instanceof Integer)) {
            throw new ClassCastException("An Integer object expected.");
        }

        //increment input value by 10
        return new Integer(((Integer) input).intValue() + 10);
    }
}
