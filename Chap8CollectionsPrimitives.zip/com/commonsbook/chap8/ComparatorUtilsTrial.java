package com.commonsbook.chap8;
import org.apache.commons.collections.ComparatorUtils;

import java.util.Comparator;

public class ComparatorUtilsTrial {
    public static void main(String[] args) {
        Human one = new Human("HumanTwo", 22);
        Human two = null;
        Human three = new Human("HumanThree", 33);

        //Get Comparator that treats a null value as higher than a non null value
        Comparator cn = ComparatorUtils.nullHighComparator(new HumanComparator());
        Human maxHuman = (Human) ComparatorUtils.max(one, two, cn);
        Human minHuman = (Human) ComparatorUtils.min(one, two, cn);
        System.out.println("** MAX IS >>" + maxHuman);
        System.out.println("** MIN IS >>" + minHuman);

        //Get Comparator that will reverse the comparator logic
        Comparator rev = ComparatorUtils.reversedComparator(new HumanComparator());
        Human revMaxHuman = (Human) ComparatorUtils.max(one, three, rev);
        Human revMinHuman = (Human) ComparatorUtils.min(one, three, rev);
        System.out.println("## REV MAX IS >>" + revMaxHuman);
        System.out.println("## REV MIN IS >>" + revMinHuman);
    }
}
