package com.commonsbook.chap8;
import org.apache.commons.collections.FastArrayList;

import java.util.ArrayList;

public class FastArrayListTrial {
    public static void main(String[] args) {
        //create a new FastArrayList and ArrrayList.
        FastArrayList fArList = new FastArrayList();
        ArrayList arList = new ArrayList();

        //Add a million strings to the list
        //Use new String to stop JVM from reusing String instances.
        for (int i = 0; i < 1000000; i++) {
            fArList.add(new String("AString"));
            arList.add(new String("AString"));
        }

        //Get time in milliseconds
        long utilBegin = System.currentTimeMillis();

        for (int util = 0; util < 1000000; util++) {
            fArList.get(util);
        }

        System.out.println("UTIL ArrayList Milliseconds Taken = " +
            (System.currentTimeMillis() - utilBegin));

        long slowBegin = System.currentTimeMillis();

        for (int slow = 0; slow < 1000000; slow++) {
            fArList.get(slow);
        }

        System.out.println("SLOW FastArrayList Milliseconds Taken = " +
            (System.currentTimeMillis() - slowBegin));

        fArList.setFast(true);

        long fastBegin = System.currentTimeMillis();

        for (int fast = 0; fast < 100000; fast++) {
            fArList.get(fast);
        }

        System.out.println("FAST FastArrayList Milliseconds Taken = " +
            (System.currentTimeMillis() - fastBegin));
    }
}
