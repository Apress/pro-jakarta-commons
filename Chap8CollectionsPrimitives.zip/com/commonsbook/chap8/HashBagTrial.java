   package com.commonsbook.chap8;
   import org.apache.commons.collections.bag.HashBag;
   
   import java.util.Iterator;
   import java.util.Set;
   
   public class HashBagTrial {
       public static void main(String[] args) {
           HashBag hBag = new HashBag();
           Human h1 = new Human("One", 22);
           Human h2 = new Human("Two", 32);
   
           hBag.add(h1, 5);
   
           hBag.add(h2);
           h2.setAge(44);
           hBag.add(h2);
   
           System.out.println("h1 count>>" + hBag.getCount(h1));
           System.out.println("h2 count>>" + hBag.getCount(h2));
   
           Set uSet = hBag.uniqueSet();
           Iterator uSetItr = uSet.iterator();

           while (uSetItr.hasNext()) {
               System.out.println(uSetItr.next());
           }
       }
   }
