package com.commonsbook.chap8;
import org.apache.commons.collections.IteratorUtils;

import java.util.Iterator;
import java.util.List;

public class IteratorUtilsTrial {
    public static void main(String[] args) {
        String[] weekDays = new String[] { "Mon", "Tue", "Wed", "Thu", "Fri" };
        Iterator daysItr = IteratorUtils.arrayIterator(weekDays, 1, 3);

        while (daysItr.hasNext()) {
            System.out.println("## itr =" + daysItr.next());
        }

        Iterator daysItr1 = IteratorUtils.arrayIterator(weekDays, 2);
        List daysList = IteratorUtils.toList(daysItr1);

        for (int i = 0; i < daysList.size(); i++) {
            System.out.println(">> list =" + daysList.get(i));
        }
    }
}
