package com.commonsbook.chap8;
import org.apache.commons.collections.buffer.BoundedFifoBuffer;
import org.apache.commons.collections.buffer.UnboundedFifoBuffer;

public class FifoBufferTrial {
    public static void main(String[] args) {
        BoundedFifoBuffer bFifoBuffer = new BoundedFifoBuffer(3);
        bFifoBuffer.add("B One");
        bFifoBuffer.add("B Two");
        bFifoBuffer.add("B Three");

        System.out.println("Bounded Get >>" + bFifoBuffer.get());
        System.out.println("Bounded Remove >>" + bFifoBuffer.remove());
        System.out.println("Bounded Remove >>" + bFifoBuffer.remove());
        System.out.println("Bounded Size >>" + bFifoBuffer.size());

        UnboundedFifoBuffer unbFifoBuffer = new UnboundedFifoBuffer(1);
        unbFifoBuffer.add("UB One");
        unbFifoBuffer.add("UB Two");
        unbFifoBuffer.add("UB Three");

        System.out.println("\nUnbounded Get >>" + unbFifoBuffer.get());
        System.out.println("Unbounded Remove >>" + unbFifoBuffer.remove());
        System.out.println("Unbounded Remove >>" + unbFifoBuffer.remove());
        System.out.println("Unbounded Size >>" + unbFifoBuffer.size());
    }
}
