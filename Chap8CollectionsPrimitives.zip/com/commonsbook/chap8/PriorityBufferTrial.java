package com.commonsbook.chap8;
import org.apache.commons.collections.buffer.PriorityBuffer;

public class PriorityBufferTrial {
    public static void main(String[] args) {
        PriorityBuffer bHeapOne = new PriorityBuffer();
        bHeapOne.add(new Integer(44));
        bHeapOne.add(new Integer(11));
        bHeapOne.add(new Integer(99));

        System.out.println(">>" + bHeapOne.remove());
        System.out.println(">>" + bHeapOne.remove());
        System.out.println(">>" + bHeapOne.remove());

        PriorityBuffer bHeapTwo = new PriorityBuffer(new HumanComparator());
        bHeapTwo.add(new Human("HumanTwo", 22));
        bHeapTwo.add(new Human("HumanOne", 11));
        bHeapTwo.add(new Human("HumanThree", 33));

        System.out.println("##" + bHeapTwo.remove());
        System.out.println("##" + bHeapTwo.remove());
        System.out.println("##" + bHeapTwo.remove());
    }
}
