package com.commonsbook.chap8;
import org.apache.commons.collections.primitives.ArrayIntList;
import org.apache.commons.collections.primitives.IntIterator;

public class UseIntPrimitive {
    public static void main(String[] args) {
        ArrayIntList aIntList = new ArrayIntList();
        aIntList.add(1);
        aIntList.add(2);

        IntIterator intItr = aIntList.iterator();

        while (intItr.hasNext()) {
            System.out.println(">> " + intItr.next());
        }

        //Set 8 at index 1 
        aIntList.set(1, 8);
        System.out.println("Value at index 1 >>" + aIntList.get(1));
    }
}
