package com.commonsbook.chap4;
import org.apache.struts.validator.ValidatorForm;

public final class UserForm extends ValidatorForm {

    private String firstName = null;
    private String lastName = null;
    private String email = null;

    public String getFirstName() {
       return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
       return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
       return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
