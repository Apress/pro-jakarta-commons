package com.commonsbook.chap6;
import org.apache.commons.pool.BaseKeyedPoolableObjectFactory;

public class ComputerKeyedObjFactory extends BaseKeyedPoolableObjectFactory {
    static int i = 0;

    public Object makeObject(Object key) {
        System.out.println("\t [ComputerKeyedObjFactory] Created object " +
            ++i);

        return new Computer((String) key);
    }

    public boolean validateObject(Object key, Object obj) {
        System.out.println("\tValidating Object " + i);

        if ((obj != null) && (key != null)) {
            return true;
        } else {
            return false;
        }
    }
}
