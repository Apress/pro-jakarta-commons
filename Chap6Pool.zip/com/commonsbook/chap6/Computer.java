package com.commonsbook.chap6;

/**
 * Class holding some details of a computer
 */
public class Computer {
    //Processor Name
    private String processor;

    //Operating System
    private String operatingSystem;

    //Location of the computer
    private String location;

    public Computer() {
    }

    public Computer(String location) {
        this.location = location;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String newProcessor) {
        processor = newProcessor;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String newOperatingSystem) {
        operatingSystem = newOperatingSystem;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String newLocation) {
        location = newLocation;
    }
}
