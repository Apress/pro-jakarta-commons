package com.commonsbook.chap6;
import org.apache.commons.pool.impl.GenericObjectPool;

public class GenericObjectPoolTrial {
    public static void main(String[] args) {
        GenericObjectPool pool = new GenericObjectPool(new ComputerObjFactory());
        System.out.println("1) NumActive:" + pool.getNumActive() +
            "\tNumIdle: " + pool.getNumIdle());

        try {
            //Borrow two objects from pool
            Computer compHome = (Computer) pool.borrowObject();
            Computer compWork = (Computer) pool.borrowObject();

            System.out.println("2) NumActive:" + pool.getNumActive() +
                "\tNumIdle: " + pool.getNumIdle());

            //Return one object to pool
            pool.returnObject(compHome);

            System.out.println("3) NumActive:" + pool.getNumActive() +
                "\tNumIdle: " + pool.getNumIdle());

            //Clears the pool of all pooled instances
            pool.clear();

            System.out.println("4) NumActive:" + pool.getNumActive() +
                "\tNumIdle: " + pool.getNumIdle());

            //Close the pool
            pool.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
