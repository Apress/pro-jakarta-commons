package com.commonsbook.chap6;
import org.apache.commons.pool.BasePoolableObjectFactory;

public class ComputerObjFactory extends BasePoolableObjectFactory {
    static int i = 1;

    public Object makeObject() {
        System.out.println("\t [ComputerObjFactory] Created object " + i++);

        return new Computer();
    }

    public void passivateObject(Object obj) {
        if (obj != null) {
            System.out.println("\t [ComputerObjFactory] Passivating object");

            Computer c = (Computer) obj;
            c.setOperatingSystem(null);
            c.setProcessor(null);
            c.setLocation(null);
        }
    }
}
