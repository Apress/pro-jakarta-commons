package com.commonsbook.chap6;
import org.apache.commons.pool.impl.GenericKeyedObjectPool;

public class GenericKeyedObjectPoolTrial {
    public static void main(String[] args) {
        GenericKeyedObjectPool keyPool = new GenericKeyedObjectPool(new ComputerKeyedObjFactory());

        //Validate objects being borrowed.
        keyPool.setTestOnBorrow(true);

        System.out.println("1 home)NumActive:" + keyPool.getNumActive("home") +
            "\tNumIdle: " + keyPool.getNumIdle("home"));
        System.out.println("1 work)NumActive:" + keyPool.getNumActive("work") +
            "\tNumIdle: " + keyPool.getNumIdle("work"));

        try {
            //Borrow two objects from pool. Validate before returning
            Computer keyCompHome = (Computer) keyPool.borrowObject("home");
            Computer keyCompWork = (Computer) keyPool.borrowObject("work");

            System.out.println("2 home)NumActive:" +
                keyPool.getNumActive("home") + "\tNumIdle: " +
                keyPool.getNumIdle("home"));
            System.out.println("2 work)NumActive:" +
                keyPool.getNumActive("work") + "\tNumIdle: " +
                keyPool.getNumIdle("work"));

            //Return one object to pool
            keyPool.returnObject(keyCompHome.getLocation(), keyCompHome);

            System.out.println("3 home)NumActive:" +
                keyPool.getNumActive("home") + "\tNumIdle: " +
                keyPool.getNumIdle("home"));
            System.out.println("3 work)NumActive:" +
                keyPool.getNumActive("work") + "\tNumIdle: " +
                keyPool.getNumIdle("work"));

            //Clears the pool of all pooled instances
            keyPool.clear();

            System.out.println("4 home)NumActive:" +
                keyPool.getNumActive("home") + "\tNumIdle: " +
                keyPool.getNumIdle("home"));
            System.out.println("4 work)NumActive:" +
                keyPool.getNumActive("work") + "\tNumIdle: " +
                keyPool.getNumIdle("work"));

            //Close the pool
            keyPool.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
