package com.commonsbook.chap11;
import com.commonsbook.chap7.academy.*;

import org.apache.commons.jxpath.*;

import java.util.*;

public class UseJXPath {
    String[] daysOfWeek = new String[] {
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
            "Sunday"
        };
    Map tel = new HashMap();

    public static void main(String[] args) {
        UseJXPath useJXPath = new UseJXPath();
        useJXPath.fetchValues();
    }

    public void fetchValues() {
        Course course = new Course();
        JXPathContext courseCtx = JXPathContext.newContext(course);

        //Set Course name
        courseCtx.setValue("name", "A Course");

        Student student = new Student();
        JXPathContext studentCtx = JXPathContext.newContext(student);

        Vector courses = new Vector();
        courses.add(course);

        //Set Student name and add courses to Student
        studentCtx.setValue("name", "A Student");
        studentCtx.setValue("courses", courses);

        Academy academy = new Academy();
        JXPathContext academyCtx = JXPathContext.newContext(academy);

        Vector students = new Vector();
        students.add(student);

        //Set Academy name and all students to academy.
        academyCtx.setValue("name", "An Academy");
        academyCtx.setValue("students", students);

        System.out.println("Academy name >>" + academyCtx.getValue("name"));
        System.out.println("Academy > Student name =" +
            academyCtx.getValue("students/name"));
        System.out.println("Academy > Student Course name =" +
            academyCtx.getValue("students/courses/name"));
        System.out.println("Academy > Student =" +
            academyCtx.getValue("students[1]"));

        JXPathContext thisCtx = JXPathContext.newContext(this);

        //Iterator for daysOfWeek whose index < 6
        Iterator weekDays = thisCtx.iterate("daysOfWeek[position() < 6]");

        while (weekDays.hasNext()) {
            System.out.println("Weekday =" + weekDays.next() + "\t");
        }

        //Set into HashMap. Key is home. Value is 1111
        thisCtx.setValue("tel/home", "1111");
        System.out.println("Home Tel =" + thisCtx.getValue("tel/home"));
    }

    public void setDaysOfWeek(String[] daysOfWeek) {
        this.daysOfWeek = daysOfWeek;
    }

    public String[] getDaysOfWeek() {
        return daysOfWeek;
    }

    public void setTel(Map tel) {
        this.tel = tel;
    }

    public Map getTel() {
        return tel;
    }
}
