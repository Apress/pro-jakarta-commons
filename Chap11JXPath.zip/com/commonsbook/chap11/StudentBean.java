package com.commonsbook.chap11;
public class StudentBean {
    public int studId;
    public String name;

    public StudentBean() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setStudId(int studId) {
        this.studId = studId;
    }

    public int getStudId() {
        return studId;
    }
}
