package com.commonsbook.chap11;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.servlet.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;

public class JXPathServlet extends HttpServlet {

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        JXPathContext requestCtx = JXPathServletContexts.getRequestContext(request,
                getServletContext());
        requestCtx.setValue("testattrib", "REQ TEST VALUE");

        out.println("<html>");
        out.println("<head><title>JXPathServlet</title></head>");
        out.println("<body>");

        out.println("<p>" + requestCtx.getValue("testattrib") + "</p>");

        out.println("</body></html>");
        out.close();
    }
}
