package com.commonsbook.chap4;
import java.util.*;
import org.apache.commons.validator.*;

public class ValidationTests {
    //ResourceBundle for Validator messages.
    private static ResourceBundle valMsgsBundle = ResourceBundle.getBundle(
            "validatorMsgs");

    /**
    * Validate required.
    * @param bean The bean instance
    * @param field The field being validated
    * @param err HashMap that will hold validation errors
    * @param va ValidatorAction
    * @return if required value is provided true, else false
    */
    public static boolean validateRequired(Object bean, Field field,
        HashMap err, org.apache.commons.validator.ValidatorAction va) {
        
        String value = ValidatorUtil.getValueAsString(bean, field.getProperty());
        String fieldName = valMsgsBundle.getString(field.getArg0().getKey());
        String actionMsg = valMsgsBundle.getString(va.getMsg());

        System.out.println("#### validateRequired value=" + value);

        if (GenericValidator.isBlankOrNull(value)) {
            System.out.println("validateRequired RETURN false");
            err.put(field.getKey(), fieldName + " " + actionMsg);

            return false;
        } else {
            System.out.println("validateRequired RETURN true");

            return true;
        }
    }

    /**
    * Validate int.
    * @param bean The bean instance
    * @param field The field being validated
    * @param err HashMap that will hold validation errors
    * @param va ValidatorAction
    * @return if value is int true, else false
    */
    public static boolean validateInt(Object bean, Field field,
        HashMap err, org.apache.commons.validator.ValidatorAction va) {
        
        String value = ValidatorUtil.getValueAsString(bean, field.getProperty());
        String fieldName = valMsgsBundle.getString(field.getArg0().getKey());
        String actionMsg = valMsgsBundle.getString(va.getMsg());
        System.out.println("#### validateInt value=" + value);

        if (GenericValidator.isInt(value)) {
            System.out.println("validateInt RETURN true");

            return true;
        } else {
            System.out.println("validateInt RETURN false");
            err.put(field.getKey(), fieldName + " " + actionMsg);

            return false;
        }
    }

    /**
    * Check Range.
    * @param bean The bean instance
    * @param field The field being validated
    * @param err HashMap that will hold validation errors
    * @param va ValidatorAction
    * @return if value is within range true, else false
    */
    public static boolean checkRange(Object bean, Field field, HashMap err,
        org.apache.commons.validator.ValidatorAction va) {
        
        String value = ValidatorUtil.getValueAsString(bean, field.getProperty());
        String fieldName = valMsgsBundle.getString(field.getArg0().getKey());
        String actionMsg = valMsgsBundle.getString(va.getMsg());

        System.out.println("#### checkRange value=" + value);

        Var max = field.getVar("max");
        Var min = field.getVar("min");

        String maxVal = max.getValue();
        String minVal = min.getValue();

        if (GenericValidator.isInRange(Integer.parseInt(value),
                    Integer.parseInt(minVal), Integer.parseInt(maxVal))) {
            System.out.println("checkRange RETURN true");

            return true;
        } else {
            System.out.println("checkRange RETURN false");
            err.put(field.getKey(), fieldName + " " + actionMsg);

            return false;
        }
    }
}
