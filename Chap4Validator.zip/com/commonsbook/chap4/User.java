package com.commonsbook.chap4;
public class User {
    private String name;
    private String age;

    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String newAge) {
        age = newAge;
    }
}
