package com.commonsbook.chap4;
import org.apache.commons.validator.*;
import java.io.*;
import java.util.*;

public class ValidationTrial {
    public static void main(String[] args)
        throws IOException, ValidatorException {
        ValidationTrial validationTrial = new ValidationTrial();
        validationTrial.validateMeth(args[0], args[1]);
    }

    /**
    * The method that initializes and validates a User bean's fields.
    * @param age Age
    * @param name Name
    * @throws IOException
    * @throws ValidatorException
    */
    public void validateMeth(String age, String name)
        throws IOException, ValidatorException {
        //Get Validator Configuration File as stream
        InputStream in = this.getClass().getClassLoader().getResourceAsStream("validate-bean.xml");

        //Initialize ValidatorResourcess based on contents on validate-bean.xml
        ValidatorResources vRes = ValidatorResourcesInitializer.initialize(in);

        //Initialize a new bean. The contents of this bean will be validated.
        User uBean = new User();
        uBean.setAge(age);
        uBean.setName(name);

        //Create a new validator using
        //the initialized ValidatorResources and for form nameForm
        Validator val = new Validator(vRes, "nameForm");

        //Add to the validator the bean instance that is to be validated.
        val.addResource(Validator.BEAN_KEY, uBean);

        //Add HashMap as a resource where we will store all validation errors.
        HashMap err = new HashMap();
        val.addResource("java.util.HashMap", err);

        //Get Form from the ValidationResources.
        Form nForm = vRes.get(Locale.getDefault(), "nameForm");

        System.out.println("Validator actions >>>" +
            vRes.getValidatorActions());

        //Validate and get validation results.
        ValidatorResults valResults = val.validate();

        System.out.println("HashMap of validation errors >>>" +
            val.getResource("java.util.HashMap"));
    }
}
