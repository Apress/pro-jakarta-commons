package com.commonsbook.chap5;
/**
 * Class holding bare minimum details of a computer
 */
public class Computer {
private String processor;
private String ramDetails;
private String operatingSystem;
private String adminUser;
    
    public Computer() {
    }
    
    public String getProcessor() {
        return processor;
    }
    
    public void setProcessor(String newProcessor) {
        processor = newProcessor;
    }
    
    public String getRamDetails() {
        return ramDetails;
    }
    
    public void setRamDetails(String newRamDetails) {
        ramDetails = newRamDetails;
    }
    
    public String getOperatingSystem() {
        return operatingSystem;
    }
    
    public void setOperatingSystem(String newOperatingSystem) {
        operatingSystem = newOperatingSystem;
    }
    
    public String getAdminUser() {
        return adminUser;
    }
}