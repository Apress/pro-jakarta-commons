package com.commonsbook.chap5;
import org.apache.commons.beanutils.PropertyUtils;

import java.util.ArrayList;
import java.util.HashMap;

public class BeanUtilsPersonTrial {
    public static void main(String[] args) throws Exception {
        //Initialize new Person
        Person p = new Person();

        //Set Simple Properties
        PropertyUtils.setSimpleProperty(p, "name", "Mr. X");
        PropertyUtils.setSimpleProperty(p, "age", new Integer(30));

        PropertyUtils.setSimpleProperty(p, "pastEmployers",
            new String[] { "Microsoft", "Sun", "IBM" });

        //ArrayList of certifications
        ArrayList cert = new ArrayList();
        cert.add("SCJP");
        cert.add("SCWCD");

        PropertyUtils.setSimpleProperty(p, "certifications", cert);

        PropertyUtils.setSimpleProperty(p, "phoneNumbers", new HashMap());
        PropertyUtils.setSimpleProperty(p, "homeComputer", new Computer());
        PropertyUtils.setSimpleProperty(p, "workComputer", new Computer());

        //Set string at index 0 in array
        PropertyUtils.setIndexedProperty(p, "pastEmployers", 0, "BEA");
        PropertyUtils.setIndexedProperty(p, "certifications", 1, "SCEA");

        //Set Mapped Properties
        PropertyUtils.setMappedProperty(p, "phoneNumbers", "home", "111222333");
        PropertyUtils.setMappedProperty(p, "phoneNumbers", "office", "00000000");

        //Set Mapped Properties
        PropertyUtils.setNestedProperty(p, "homeComputer.processor", "Intel P4");
        PropertyUtils.setNestedProperty(p, "homeComputer.ramDetails", "512 MB");
        PropertyUtils.setNestedProperty(p, "homeComputer.operatingSystem",
            "Win2K");

        System.out.println("***Simple Property Access***");
        System.out.println("\tSimpProp name= " +
            PropertyUtils.getSimpleProperty(p, "name"));
        System.out.println("\tSimpProp age= " +
            PropertyUtils.getSimpleProperty(p, "age"));

        System.out.println("***Mapped Property Access***");
        System.out.println("\tMapProp phoneNumbers > home= " +
            PropertyUtils.getMappedProperty(p, "phoneNumbers", "home"));
        System.out.println("\tMapProp phoneNumbers > office= " +
            PropertyUtils.getMappedProperty(p, "phoneNumbers(office)"));

        System.out.println("***Indexed Property Access***");
        System.out.println("\tIndProp pastEmployers[0] = " +
            PropertyUtils.getIndexedProperty(p, "pastEmployers", 0));
        System.out.println("\tIndProp certifications[1] = " +
            PropertyUtils.getIndexedProperty(p, "certifications[1]"));

        System.out.println("***Nested Property Access***");
        System.out.println("\tNestedProperty homeComputer.processor = " +
            PropertyUtils.getNestedProperty(p, "homeComputer.processor"));
        System.out.println("\tNestedProperty homeComputer.ramDetails = " +
            PropertyUtils.getNestedProperty(p, "homeComputer.ramDetails"));
        System.out.println("\tNestedProperty homeComputer.operatingSystem = " +
            PropertyUtils.getNestedProperty(p, "homeComputer.operatingSystem"));

        System.out.println("***Other Utilities***");
        System.out.println("Describe the object: \n" +
            PropertyUtils.describe(p));
        System.out.println("homeComputer.adminUser Readable = " +
            PropertyUtils.isReadable(p, "homeComputer.adminUser"));
        System.out.println("homeComputer.adminUser Writable = " +
            PropertyUtils.isWriteable(p, "homeComputer.adminUser"));

    }
}
