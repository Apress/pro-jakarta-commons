package com.commonsbook.chap5;
import org.apache.commons.beanutils.BeanComparator;

public class BeanComparatorTrial {
    public static void main(String[] args) {
        Person p1 = new Person();
        p1.setAge(30);

        Person p2 = new Person();
        p2.setAge(20);

        BeanComparator bcomp = new BeanComparator("age");
        System.out.println("On comparing p1 with p2 >>>"+bcomp.compare(p1, p2));
    }
}
