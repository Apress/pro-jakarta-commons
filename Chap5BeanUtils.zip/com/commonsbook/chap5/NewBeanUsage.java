package com.commonsbook.chap5;
import org.apache.commons.beanutils.BasicDynaClass;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.PropertyUtils;

public class NewBeanUsage {
    public static void main(String[] args) throws Exception {
        //Define properties for the dynamic class
        DynaProperty[] props = new DynaProperty[] {
                new DynaProperty("aField", java.lang.String.class)
            };

        //Define the class
        BasicDynaClass dynaClass = new BasicDynaClass("AnotherBean", null, props);

        //Instantiate the class
        DynaBean dBean = dynaClass.newInstance();

        //Set property value
        PropertyUtils.setSimpleProperty(dBean, "aField", "VALUE");

        //Get Property value
        System.out.println("AField = " +
            PropertyUtils.getSimpleProperty(dBean, "aField"));
    }
}
