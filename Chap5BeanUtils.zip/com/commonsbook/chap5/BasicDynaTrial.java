package com.commonsbook.chap5;
import org.apache.commons.beanutils.BasicDynaBean;
import org.apache.commons.beanutils.BasicDynaClass;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.PropertyUtils;

import java.util.ArrayList;

public class BasicDynaTrial {
    public static void main(String[] args) throws Exception {
        //Define properties for the dynamic class
        DynaProperty[] props = new DynaProperty[] {
                new DynaProperty("arPropOne", ArrayList.class)
            };

        //ArrayList meant to be set as a property.
        ArrayList arObjs = new ArrayList();
        arObjs.add("OBJ1");
        arObjs.add("OBJ2");

        //Define the class
        BasicDynaClass basicDynaClass = new BasicDynaClass("BasicBean", null,
                props);

        //Instantiate the class
        DynaBean dBean = basicDynaClass.newInstance();

        //Another way to instantiate a BasicDynaBean
        BasicDynaBean basicDB = new BasicDynaBean(basicDynaClass);

        //Set property value
        PropertyUtils.setSimpleProperty(dBean, "arPropOne", arObjs);

        //Get Property value
        System.out.println("[dBean] ArrayList arObjs = " +
            PropertyUtils.getSimpleProperty(dBean, "arPropOne"));

        //Get Indexed Property value
        System.out.println("[dBean] arObjs[1] = " +
            PropertyUtils.getIndexedProperty(dBean, "arPropOne", 1));
    }
}
