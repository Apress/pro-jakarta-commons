package com.commonsbook.chap5;
public class OldBeanUsage {
    public static void main(String[] args) {
        //Instantiate Bean
        TheBean bean = new TheBean();

        //Set Property Value
        bean.setAField("VALUE");

        //Get Property Value
        System.out.println("AField = " + bean.getAField());
    }
}


/**
 * Define a separate class for the Bean
 */
class TheBean {
    private String aField;

    public TheBean() {
    }

    public String getAField() {
        return aField;
    }

    public void setAField(String newAField) {
        aField = newAField;
    }
}
