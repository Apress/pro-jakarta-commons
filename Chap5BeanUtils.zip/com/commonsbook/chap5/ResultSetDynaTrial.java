package com.commonsbook.chap5;
import java.sql.*;
import java.util.*;
import org.apache.commons.beanutils.*;

public class ResultSetDynaTrial {
    public static void main(String[] args) {
        Connection con =null;
        Statement st =null;
        ResultSet rs =null;
        
        try {
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            //String url="jdbc:odbc:BeanUtilsDB";
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://127.0.0.1:3306/test";
            con = DriverManager.getConnection(url,"", "");
            st= con.createStatement();
            rs= st.executeQuery(
            "SELECT UserName as uName, AgE FROM USER"
            );
            ResultSetDynaClass rsDynaClass= new ResultSetDynaClass(rs);
            Iterator itr= rsDynaClass.iterator();
            
            while(itr.hasNext()) {
                DynaBean dBean= (DynaBean)itr.next();
                System.out.println("username "
                    +PropertyUtils.getSimpleProperty(dBean, "uname"));
                System.out.println("age "
                    +PropertyUtils.getSimpleProperty(dBean, "age"));
                //System.out.println(PropertyUtils.describe(dBean));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null) { rs.close(); }  
                if(st!=null) { st.close(); }
                if(con!=null) { con.close(); }
            }
            catch(Exception e) { e.printStackTrace(); }
        }
    }
}