package com.commonsbook.chap5;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.WrapDynaBean;

import java.util.ArrayList;
import java.util.HashMap;

public class WrapDynaTrial {
    public static void main(String[] args) throws Exception {
        DynaBean personDyBean = new WrapDynaBean(new Person());

        personDyBean.set("name", "Mr. X");
        personDyBean.set("age", new Integer(30));
        personDyBean.set("pastEmployers",
            new String[] { "Microsoft", "Sun", "IBM" });

        //ArrayList of certifications
        ArrayList cert = new ArrayList();
        cert.add("SCJP");
        cert.add("SCWCD");

        //Set Simple Properties
        personDyBean.set("certifications", cert);
        personDyBean.set("phoneNumbers", new HashMap());
        personDyBean.set("homeComputer", new Computer());
        personDyBean.set("workComputer", new Computer());

        //Set Indexed Properties
        personDyBean.set("pastEmployers", 0, "BEA");
        personDyBean.set("certifications", 1, "SCEA");

        //Set Mapped Properties
        personDyBean.set("phoneNumbers", "home", "111222333");
        personDyBean.set("phoneNumbers", "office", "00000000");

        //Set Nested Properties
        DynaBean homeComp = new WrapDynaBean(personDyBean.get("homeComputer"));
        homeComp.set("processor", "Intel P4");
        homeComp.set("ramDetails", "512 MB");
        homeComp.set("operatingSystem", "Win2K");

        System.out.println("***Simple Property Access***");
        System.out.println("\tSimpProp name= " + personDyBean.get("name"));
        System.out.println("\tSimpProp age= " + personDyBean.get("age"));

        System.out.println("***Mapped Property Access***");
        System.out.println("\tMapProp phoneNumbers > home= " +
            personDyBean.get("phoneNumbers", "home"));
        System.out.println("\tMapProp phoneNumbers > office= " +
            personDyBean.get("phoneNumbers", "office"));

        System.out.println("***Indexed Property Access***");
        System.out.println("\tIndProp pastEmployers[0] = " +
            personDyBean.get("pastEmployers", 0));
        System.out.println("\tIndProp certifications[1] = " +
            personDyBean.get("certifications", 1));

        System.out.println("***Nested Property Access***");
        System.out.println("\tNestedProperty homeComputer.processor = " +
            new WrapDynaBean(personDyBean.get("homeComputer")).get("processor"));
        System.out.println("\tNestedProperty homeComputer.ramDetails = " +
            new WrapDynaBean(personDyBean.get("homeComputer")).get("ramDetails"));
        System.out.println("\tNestedProperty homeComputer.operatingSystem = " +
            new WrapDynaBean(personDyBean.get("homeComputer")).get(
                "operatingSystem"));
    }
}
