package com.commonsbook.chap5;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

/**
 * Some Details about a person
 */
public class Person {
    private String name; //Simple property
    private int age; //Simple property
    private HashMap phoneNumbers; //Mapped property
    private Computer homeComputer; //Simple property
    private Computer workComputer; //Simple property
    private String[] pastEmployers; // Indexed property
    private ArrayList certifications = new ArrayList(); //Indexed property

    public Person() {
        certifications.add("SCJP");
        certifications.add("SCWCD");
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int newAge) {
        age = newAge;
    }

    public HashMap getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(HashMap newPhoneNumbers) {
        phoneNumbers = newPhoneNumbers;
    }

    public Computer getHomeComputer() {
        return homeComputer;
    }

    public void setHomeComputer(Computer newHomeComputer) {
        homeComputer = newHomeComputer;
    }

    public Computer getWorkComputer() {
        return workComputer;
    }

    public void setWorkComputer(Computer newWorkComputer) {
        workComputer = newWorkComputer;
    }

    public String[] getPastEmployers() {
        return (pastEmployers);
    }

    /*
        public String getPastEmployers(int index) {
            return (pastEmployers[index]);
        }

        public void setPastEmployers(int index, String value) {
            pastEmployers[index] = value;
        }
    */
    public void setPastEmployers(String[] pastEmployers) {
        this.pastEmployers = pastEmployers;
    }

    public ArrayList getCertifications() {
        return certifications;
    }

    public void setCertifications(ArrayList newCertifications) {
        this.certifications = newCertifications;
    }

    /*
        public String getCertifications(int index) {
            return (String) certifications.get(index);
        }

        public void setCertifications(int index, String value) {
            certifications.set(index, value);
        }
    */
}
