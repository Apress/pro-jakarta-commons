package com.commonsbook.chap5;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.RowSetDynaClass;

public class RowSetDynaTrial {
    public static void main(String[] args) {
        Connection con = null;
        Statement st= null;
        ResultSet rs =null;
        
        try {
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            //String url="jdbc:odbc:BeanUtilsDB";
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://127.0.0.1:3306/test";
            con = DriverManager.getConnection(url,"", "");
            st= con.createStatement();
            rs= st.executeQuery(
            "SELECT UserName as uName, AgE FROM USER");
            RowSetDynaClass rsDynaClass= new RowSetDynaClass(rs);
            //Close ResultSet right away
            rs.close();
            
            List rows= rsDynaClass.getRows();
            Iterator itr= rows.iterator();
            
            while(itr.hasNext()) {
                DynaBean dBean= (DynaBean)itr.next();
                System.out.println("username "
                    +PropertyUtils.getSimpleProperty(dBean, "uname"));
                System.out.println("age "
                    +PropertyUtils.getSimpleProperty(dBean, "age"));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if(rs!=null) { rs.close(); }
                if(st!=null) { st.close(); }
                if(con!=null) { con.close(); }
            }
            catch(Exception e) { e.printStackTrace(); }
        }
    }
}