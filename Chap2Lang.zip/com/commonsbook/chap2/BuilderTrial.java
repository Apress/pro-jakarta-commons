package com.commonsbook.chap2;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class BuilderTrial {
    private String name;
    private int age;

    public BuilderTrial(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public static void main(String[] args) {
        //Create new BuilderTrial instances
        BuilderTrial one = new BuilderTrial("Becker", 35);
        BuilderTrial two = new BuilderTrial("Becker", 35);
        BuilderTrial three = new BuilderTrial("Agassi", 33);

        //one and two hold the same data in different objects
        //three holds different data
        System.out.println("One>>>" + one);
        System.out.println("Two>>>" + two);
        System.out.println("Three>>>" + three);

        System.out.println("one equals two? " + one.equals(two));
        System.out.println("one equals three? " + one.equals(three));

        //As one and two hold the same data, the same hashcode is returned.
        System.out.println("One HashCode>>> " + one.hashCode());
        System.out.println("Two HashCode>>> " + two.hashCode());
        System.out.println("Three HashCode>>> " + three.hashCode());
    }

    public boolean equals(Object objCompared) {
        if (!(objCompared instanceof BuilderTrial)) {
            return false;
        }

        BuilderTrial rhs = (BuilderTrial) objCompared;

        return new EqualsBuilder().append(name, rhs.name).append(age, rhs.age)
                                  .isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE).append("Name",
            name).append("Age", age).toString();
    }

    public int hashCode() {
        return new HashCodeBuilder(15, 19).append(name).append(age).toHashCode();
    }
}
