package com.commonsbook.chap2;
import org.apache.commons.lang.SystemUtils;

public class SystemUtilsTrial {
    public static void main(String[] args) {
        System.out.println("1) FILE_SEPARATOR =" + SystemUtils.FILE_SEPARATOR);
        System.out.println("2) JAVA_EXT_DIRS =" + SystemUtils.JAVA_EXT_DIRS);
        System.out.println("3) JAVA_HOME =" + SystemUtils.JAVA_HOME);
        System.out.println("4) Is 1.3 + =" +
            SystemUtils.isJavaVersionAtLeast(1.3f));
        System.out.println("5) JAVA_EXT_DIRS =" + SystemUtils.JAVA_EXT_DIRS);
        System.out.println("6) JAVA_VENDOR =" + SystemUtils.JAVA_VENDOR);
        System.out.println("7) OS_NAME =" + SystemUtils.OS_NAME);
    }
}
