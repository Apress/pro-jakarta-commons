package com.commonsbook.chap2;
import org.apache.commons.lang.ObjectUtils;

public class ObjectUtilsTrial {
    public static void main(String[] args) {
        //Create ObjectUtilsTrial instance
        ObjectUtilsTrial one = new ObjectUtilsTrial();
        ObjectUtilsTrial two = one; //Same Reference
        ObjectUtilsTrial three = new ObjectUtilsTrial(); //New Object
        ObjectUtilsTrial four = null;

        //four is null, returns DEFAULT
        System.out.print("1) If null return DEFAULT >>>");
        System.out.println(ObjectUtils.defaultIfNull(four, "DEFAULT"));

        //one and two point to the same object
        System.out.print("2) References to the same object >>>");
        System.out.println(ObjectUtils.equals(one, two));

        //one and three are different objects
        System.out.print("3) Check object references and not values >>>");
        System.out.println(ObjectUtils.equals(one, three));

        //toString method gets called
        System.out.print("4) toSring gets invoked >>>");
        System.out.println(one);

        //Object details displayed..toString is not called
        System.out.print("5) Display object details >>>");
        System.out.println(ObjectUtils.identityToString(one));

        //Pass null get empty string
        System.out.print("6) Pass null and get back an Empty string >>>");
        System.out.println("**" + ObjectUtils.toString(null) + "**");
    }

    public String toString() {
        return "toString Output";
    }
}
