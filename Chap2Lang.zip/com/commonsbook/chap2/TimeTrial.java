package com.commonsbook.chap2;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang.time.StopWatch;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class TimeTrial {
    public static void main(String[] args) {
        //Format Date into dd-MM-yyyy
        System.out.println("1) dd-MM-yyyy >>>" +
            DateFormatUtils.format(new Date(), "dd-MM-yyyy"));

        //Format Date into SMTP_DATETIME_FORMAT
        System.out.println("2) SMTP_DATETIME_FORMAT >>>" +
            DateFormatUtils.SMTP_DATETIME_FORMAT.format(new Date()));

        //Format Date into ISO_DATE_FORMAT
        System.out.println("3) ISO_DATE_FORMAT >>>" +
            DateFormatUtils.ISO_DATE_FORMAT.format(new Date()));

        //Format milliseconds in long
        System.out.println("4) MMM dd yy HH:mm >>>" +
            DateFormatUtils.format(System.currentTimeMillis(), "MMM dd yy HH:mm"));

        //Format milliseconds in long using UTC timezone
        System.out.println("5) MM/dd/yy HH:mm >>>" +
            DateFormatUtils.formatUTC(System.currentTimeMillis(),
                "MM/dd/yy HH:mm"));

        StopWatch stWatch = new StopWatch();

        //Start StopWatch
        stWatch.start();

        //Get iterator for all days in a week starting Monday
        Iterator itr = DateUtils.iterator(new Date(),
                DateUtils.RANGE_WEEK_MONDAY);

        while (itr.hasNext()) {
            Calendar gCal = (Calendar) itr.next();
            System.out.println(gCal.getTime());
        }

        //Stop StopWatch
        stWatch.stop();
        System.out.println("Time Taken >>" + stWatch.getTime());
    }
}
