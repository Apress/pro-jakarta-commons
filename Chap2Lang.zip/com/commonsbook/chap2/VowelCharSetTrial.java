package com.commonsbook.chap2;
import org.apache.commons.lang.CharSet;

public class VowelCharSetTrial {
    public static void main(String[] args) {
        //Create a new vowel character set
        CharSet vChs = CharSet.getInstance("aeiou");

        String strTest = "The quick brown fox jumps over the lazy dog.";
        int iVowelCnt = 0;
        int iTestLen = strTest.length();

        for (int i = 0; i < iTestLen; i++) {
            if (vChs.contains(strTest.charAt(i))) {
                iVowelCnt++; //increment count on a vowel being found
            }
        }
        System.out.println("String >>" + strTest);
        System.out.println("Number of vowels in the string is " + iVowelCnt);
    }
}
