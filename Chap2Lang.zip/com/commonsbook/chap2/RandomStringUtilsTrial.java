package com.commonsbook.chap2;
import org.apache.commons.lang.RandomStringUtils;

public class RandomStringUtilsTrial {
    public static void main(String[] args) {
        //Random 8 chars string from within the characters ABCDEF
        System.out.print("1) 8 char string using chars ABCDEF >>>");
        System.out.println(RandomStringUtils.random(8, "ABCDEF"));

        //Random 8 chars string where letters are enabled while numbers are not.
        System.out.print("2) 8 char string using letters but no numbers >>>");
        System.out.println(RandomStringUtils.random(8, true, false));

        //Random 8 chars string Alphanumeric 
        System.out.print("3) 8 char Alphanumeric string >>>");
        System.out.println(RandomStringUtils.randomAlphanumeric(8));

        //Random 8 chars string Alphabets only
        System.out.print("4) 8 char string -Alphabets only >>>");
        System.out.println(RandomStringUtils.randomAlphabetic(8));

        //Random 8 chars string using only the elements in the array aChars
        //Only charcters between place 0 and 5 in the array can be used.
        //Both letters and numbers are permitted
        System.out.print(
            "5) 8 char string using specific characters in an array >>>");

        char[] aChars = new char[] { 'a', '1', 'c', '2', 'e', 'f', 'g' };
        System.out.println(RandomStringUtils.random(8, 0, 5, true, true, aChars));

        // Begin Lottery code
        System.out.print("6) The two digit lucky number for the day is >>>");
        System.out.println(RandomStringUtils.randomNumeric(2));
        // End Lottery code
    }
}
