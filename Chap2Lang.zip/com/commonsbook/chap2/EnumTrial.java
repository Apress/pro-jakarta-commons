package com.commonsbook.chap2;
import org.apache.commons.lang.enum.Enum;
import org.apache.commons.lang.enum.EnumUtils;

import java.util.Iterator;
import java.util.Map;

public class EnumTrial {
    public static void main(String[] args) {
        Enum e1 = EnumUtils.getEnum(ComponentsEnum.class, "Validator");
        System.out.println("Name of Enum >>>" + e1.getName());

        Iterator itr1 = EnumUtils.iterator(ComponentsEnum.class);

        while (itr1.hasNext()) {
            System.out.println(itr1.next());
        }

        Map map1 = EnumUtils.getEnumMap(ComponentsEnum.class);
        System.out.println("Map Size >>>" + map1.size());
        System.out.println("Get Logging from Enum >>>" + map1.get("Logging"));
    }
}


/**
 * An enumeration of some Commons components
 */
class ComponentsEnum extends Enum {
    public static final ComponentsEnum LANG = new ComponentsEnum("Lang");
    public static final ComponentsEnum LOGGING = new ComponentsEnum("Logging");
    public static final ComponentsEnum COLLECTIONS = new ComponentsEnum(
            "Collections");
    public static final ComponentsEnum VALIDATOR = new ComponentsEnum(
            "Validator");
    public static final ComponentsEnum DIGESTER = new ComponentsEnum("Digester");

    public ComponentsEnum(String componentName) {
        super(componentName);
    }
}
