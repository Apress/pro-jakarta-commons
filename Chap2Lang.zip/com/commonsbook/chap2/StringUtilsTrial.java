package com.commonsbook.chap2;
import org.apache.commons.lang.StringUtils;

public class StringUtilsTrial {
    public static void main(String[] args) {
        //String can be max 12 chars including the ...
        System.out.println("1) Abbreviate Once upon a time >>>" +
            StringUtils.abbreviate("Once upon a time ", 12));

        //Returns index where the Strings start to differ
        System.out.println(
            "2) Index Of Difference between ABCXYZ and ABCPQR >>>" +
            StringUtils.indexOfDifference("ABCXYZ", "ABCPQR"));

        //Remove the specified string at the end of String
        System.out.println("3) Chomp END >>>" +
            StringUtils.chomp("A test String END", "END"));

        //Check if string contains only a specified set of characters. Return boolean
        System.out.println("4) Check if 643287460 contains only 0123456789 >>>" +
            StringUtils.containsOnly("643287460", "0123456789"));

        //Compare two strings. Case Sensitive
        System.out.println("5) Compare ABCDEFG and ABCdefg >>>" +
            StringUtils.difference("ABCDEFG", "ABCdefg"));

        //Takes Object input and returns Empty String if null.
        System.out.println("6) Return default string >>>" + "**" +
            StringUtils.defaultString(null) + "**");

        //Join all Strings in the Array into a Single String, separated by $#$ 
        System.out.println("7) Join Strings using separator >>>" +
            StringUtils.join(new String[] { "AB", "CD", "EF" }, "$#$"));

        //SubString
        System.out.println("8) Substring >>>" +
            StringUtils.substring("SUBSTRING", 1, 5));

        //Reverse a String
        System.out.println("9) Reverse >>>" + StringUtils.reverse("REVERSE"));

        //No NullPointer Exception even if null!
        System.out.println("10) Trim String. No NullPointerException >>>" +
            StringUtils.trim(null));

        //If string is null, empty string returned. Else returns trimmed string
        System.out.println("11) Empty String >>>" +
            StringUtils.trimToEmpty(null) + "<<<");

        //Compare Strings...No NullPointer Exception!
        System.out.println("12) Comapre null and null >>>" +
            StringUtils.equals(null, null));

        //Strip whitespace from start and end of the string.
        //If null returns empty string
        System.out.println("13) Strip whitespace >>>" +
            StringUtils.stripToEmpty("     ABCD      "));

        //Check that a string does not contain any of these characters !@#$%^&*
        System.out.println("14) Check that ABCD contains none of !@#$%^&* >>>" +
            StringUtils.containsNone("ABCD", "!@#$%^&*"));
    }
}
