package com.commonsbook.chap2;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.exception.NestableException;

public class ExceptionTrial {
    public static void main(String[] args) {
        try {
            middleMeth();
        } catch (Exception e) {
            System.out.println(
                "Number of Throwable objects in the exception chain is: " +
                ExceptionUtils.getThrowableCount(e));
            e.printStackTrace();
        }
    }

    public static void middleMeth() throws Exception {
        try {
            theRoot();
        } catch (Exception e) {
            throw new ApplicationException("Packaged into Nestable", e);
        }
    }

    public static void theRoot() throws Exception {
        throw new Exception("The Root Exception");
    }
}


/**
 * An application specific exception
 */
class ApplicationException extends NestableException {
    public ApplicationException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
