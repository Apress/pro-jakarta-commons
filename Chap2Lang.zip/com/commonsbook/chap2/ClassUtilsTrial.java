package com.commonsbook.chap2;
import org.apache.commons.lang.ClassUtils;

public class ClassUtilsTrial {
    public static void main(String[] args) {
        System.out.println("1) Interfaces implemented by java.lang.String >>> " +
            ClassUtils.getAllInterfaces(String.class));
        System.out.println("2) SuperClasses of java.lang.String >>> " +
            ClassUtils.getAllSuperclasses(String.class));
        System.out.println("3) PackageName of a string >>> " +
            ClassUtils.getPackageName("A String", "IfNull"));
        System.out.println("4) Every String is an Object = " +
            ClassUtils.isAssignable(String.class, Object.class));
        System.out.println("5) Every Object is an String = " +
            ClassUtils.isAssignable(Object.class, String.class));
    }
}
