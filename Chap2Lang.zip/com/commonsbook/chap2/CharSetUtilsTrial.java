package com.commonsbook.chap2;
import org.apache.commons.lang.CharSet;
import org.apache.commons.lang.CharSetUtils;

public class CharSetUtilsTrial {
    public static void main(String[] args) {
        //Count all occurrences of all the characters specified.
        System.out.println("B and o count = " +
            CharSetUtils.count("BorisBecker", "Bo")); //3
        System.out.println("B,o,k,e and r count = " +
            CharSetUtils.count("BorisBecker", new String[] { "Bo", "ker" })); //8

        //Specified characters deleted.                
        System.out.println("Delete B and o = " +
            CharSetUtils.delete("BorisBecker", "Bo")); //risecker
        System.out.println("Delete B,o,k,e and r = " +
            CharSetUtils.delete("BorisBecker", new String[] { "Bo", "ker" })); //isc

        //Keeps only the characters specified
        System.out.println("Keep B and o = " +
            CharSetUtils.keep("BorisBecker", "Bo")); //BoB

        //Removes specified character repetitions  
        System.out.println("Squeeze B and o = " +
            CharSetUtils.squeeze("BBoooorisbbbecker", "Bo")); //Borisbbbecker
    }
}
