package com.commonsbook.chap10;
import org.apache.commons.net.io.*;
import org.apache.commons.net.pop3.*;

import java.io.*;

public class POP3ClientTrial {
    public static void main(String[] args) {
        listMails("pop.example.com", "username", "password");
    }

    public static void listMails(String popserver, String username,
        String password) {
        POP3Client client = null;

        try {
            client = new POP3Client();
            System.out.println("Port >>" + client.getDefaultPort());
            client.connect(popserver);

            if (client.getState() != POP3.AUTHORIZATION_STATE) {
                System.out.println("Unable to connect to POP server");
                return;
            }

            if (!client.login(username, password)) {
                System.out.println("Unable to login to POP server");
                return;
            }

            POP3MessageInfo[] pop3Messages = client.listMessages();

            if (pop3Messages != null) {
                for (int i = 0; i < pop3Messages.length; i++) {
                    POP3MessageInfo message = pop3Messages[i];
                    System.out.println("***Identifier >>" + message.identifier);
                    System.out.println("***Number >>" + message.number);
                    System.out.println("***Size >>" + message.size);

                    Reader reader = client.retrieveMessage(message.number);
                    System.out.println(reader);

                    if (reader != null) {
                        BufferedReader bufReader = new BufferedReader(reader);
                        String line;

                        while ((line = bufReader.readLine()) != null) {
                            System.out.println(line);
                        }
                    }
                }
            }

            client.logout();
            client.disconnect();
        } catch (IOException e) {
            if (client.isConnected()) {
                try {
                    client.disconnect();
                } catch (IOException f) {
                    // ignore
                }
            }

            e.printStackTrace();
        }
    }
}
