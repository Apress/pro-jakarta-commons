package com.commonsbook.chap10;
import org.apache.commons.net.TimeTCPClient;

import java.net.InetAddress;

import java.util.Date;

public class TimeTCPClientTrial {
    public static void main(String[] args) throws Exception {
        printDateTime("gnomon.cc.columbia.edu");
    }

    public static void printDateTime(String host) throws Exception {
        TimeTCPClient client = new TimeTCPClient();

        // set timeout
        client.setDefaultTimeout(30000);
        client.connect(host);

        //Get Time in seconds
        System.out.println("Time >>" + client.getTime());

        client.connect(host);

        //Get java.util.Date
        System.out.println("Date >>" + client.getDate());

        client.disconnect();
    }
}
