package com.commonsbook.chap10;
import org.apache.commons.net.TimeUDPClient;

import java.net.InetAddress;

import java.util.Date;

public class TimeUDPClientTrial {
    public static void main(String[] args) throws Exception {
        printDateTime("gnomon.cc.columbia.edu");
    }

    public static void printDateTime(String host) throws Exception {
        TimeUDPClient client = new TimeUDPClient();

        //set timeout
        client.setDefaultTimeout(30000);

        //open socket
        client.open();

        //Get time in seconds
        System.out.println("Time >>" +
            client.getTime(InetAddress.getByName(host)));

        //Get java.util.Date
        System.out.println("Date >>" +
            client.getDate(InetAddress.getByName(host)));
        client.close();
    }
}
