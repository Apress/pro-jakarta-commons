package com.commonsbook.chap10;
import org.apache.commons.net.ftp.*;

import java.io.*;

public class FTPClientTrial {
    public static void main(String[] args) {
        new FTPClientTrial().useFTP("ftp.example.com", "/directory", "file",
            "username", "password");
    }

    public void useFTP(String ftpserver, String directoryName,
        String filetoUpload, String username, String password) {
        FTPClient ftpClient = new FTPClient();

        try {
            ftpClient.connect(ftpserver);
            System.out.print(ftpClient.getReplyString());

            // check reply code.
            if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
                ftpClient.disconnect();
                System.out.println("Connection refused.");
                return;
            }

            ftpClient.login(username, password);
            System.out.println("Workdir >>" +
                ftpClient.printWorkingDirectory());
            ftpClient.changeWorkingDirectory(directoryName);

            //Store file start
            FileInputStream input = new FileInputStream(filetoUpload);
            ftpClient.storeFile(filetoUpload, input);
            //Store file end
            
            //List all Files and directories
            FTPFile[] files = ftpClient.listFiles();

            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    //If file print name and size
                    if (files[i].isFile()) {
                        System.out.println("File >> " + files[i].getName() +
                            "\tSize >>" + files[i].getSize());
                    }
                }
            }
            System.out.println("getStatus "+ftpClient.getStatus("/www"));
            System.out.println("getSystemName "+ftpClient.getSystemName());
            System.out.println("listHelp "+ftpClient.listHelp());
            System.out.println("listNames "+ftpClient.listNames());
            ftpClient.logout();
            ftpClient.disconnect();
        } catch (IOException e) {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.disconnect();
                } catch (IOException f) {
                    // do nothing
                }
            }

            e.printStackTrace();
        }
    }
}
