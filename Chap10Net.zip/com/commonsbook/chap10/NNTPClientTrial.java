package com.commonsbook.chap10;
import org.apache.commons.net.nntp.NNTPClient;
import org.apache.commons.net.nntp.NNTPReply;
import org.apache.commons.net.nntp.NewsgroupInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

public class NNTPClientTrial {
    public static void main(String[] args) {
        listNewsgroups("freenews.netfront.net", "marathi");
    }

    public static void listNewsgroups(String servername, String keyword) {
        NNTPClient nntpClient = new NNTPClient();
        NewsgroupInfo[] list;

        try {
            nntpClient = new NNTPClient();
            nntpClient.connect(servername);

            // check reply code.
            if (!NNTPReply.isPositiveCompletion(nntpClient.getReplyCode())) {
                nntpClient.disconnect();
                System.out.println("Connection refused.");
                System.exit(1);
            }

            list = nntpClient.listNewsgroups("*" + keyword + "*");

            if ((list != null) && (list.length > 0)) {
                String newsgroup = list[0].getNewsgroup();
                System.out.println("Newsgroup >>" + newsgroup);
                System.out.println("Count >>" + list[0].getArticleCount());

                //Select Newsgroup 
                NewsgroupInfo selectedGroupInfo = new NewsgroupInfo();
                nntpClient.selectNewsgroup(newsgroup, selectedGroupInfo);

                int iFirstArticle = selectedGroupInfo.getFirstArticle();
                int iLastArticle = selectedGroupInfo.getLastArticle();

                System.out.println("First Article >>" + iFirstArticle);
                System.out.println("Last Article >>" + iLastArticle);

                //Retrieve Article
                System.out.println("**ARTICLE**");
                printFromReader(nntpClient.retrieveArticle(iFirstArticle));

                //Retrieve Article Info
                System.out.println("**ARTICLE INFO**");
                printFromReader(nntpClient.retrieveArticleInfo(iFirstArticle));

                //Retrieve Article Body
                System.out.println("**ARTICLE BODY**");
                printFromReader(nntpClient.retrieveArticleBody(iFirstArticle));

                //Retrieve Article Header
                System.out.println("**ARTICLE HEADER**");
                printFromReader(nntpClient.retrieveArticleHeader(iFirstArticle));
            }

            nntpClient.logout();
            nntpClient.disconnect();
        } catch (IOException e) {
            if (nntpClient.isConnected()) {
                try {
                    nntpClient.disconnect();
                } catch (IOException f) {
                    // do nothing
                }
            }

            e.printStackTrace();
        }
    }

    private static void printFromReader(Reader reader)
        throws IOException {
        if (reader != null) {
            BufferedReader bufReader = new BufferedReader(reader);
            String line;

            while ((line = bufReader.readLine()) != null) {
                System.out.println(line);
            }

            reader.close();
        }
    }
}
