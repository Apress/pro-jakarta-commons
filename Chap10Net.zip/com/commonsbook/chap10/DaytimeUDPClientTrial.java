package com.commonsbook.chap10;
import org.apache.commons.net.DaytimeUDPClient;

import java.net.InetAddress;

public class DaytimeUDPClientTrial {
    public static void main(String[] args) throws Exception {
        System.out.println("DayTime >>" + getDayTime("gnomon.cc.columbia.edu"));
    }

    public static String getDayTime(String host) throws Exception {
        DaytimeUDPClient client = new DaytimeUDPClient();

        // set timeout
        client.setDefaultTimeout(30000);
        client.open();

        //Get Time
        String dayTime = client.getTime(InetAddress.getByName(host)).trim();
        client.close();

        return dayTime;
    }
}
