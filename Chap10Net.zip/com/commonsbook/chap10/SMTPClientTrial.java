package com.commonsbook.chap10;
import org.apache.commons.net.smtp.SMTPClient;
import org.apache.commons.net.smtp.SMTPReply;
import org.apache.commons.net.smtp.SimpleSMTPHeader;

import java.io.IOException;
import java.io.Writer;

public final class SMTPClientTrial {
    public static void main(String[] args) {
        sendmail("smtp.example.com", "sender@example.com",
            "recipient@example.com", "ccrecipient@example.com",
            "Message Subject", "A Test message");
    }

    private static void sendmail(String smtpServer, String senderMail,
        String recipientMail, String ccrecipient, String subject, String message) {
        SMTPClient client = null;

        try {
            //Create new SMTPClient instance
            client = new SMTPClient();

            // Use the SimpleSMTPHeader class to generate a bare minimum SMTP header
            SimpleSMTPHeader header = new SimpleSMTPHeader(senderMail,
                    recipientMail, subject);

            //connect to server
            client.connect(smtpServer);

            //Print string retruend by server
            System.out.print(client.getReplyString());

            //Check Reply Code from server. 
            //All codes beginning with a 2 are positive completion responses
            if (!SMTPReply.isPositiveCompletion(client.getReplyCode())) {
                client.disconnect();
                System.out.println("Connection Refused");
                System.exit(1);
            }

            //login
            client.login();

            //Set Sender for the mail
            client.setSender(senderMail);

            //Add recepient
            client.addRecipient(recipientMail);

            if ((ccrecipient != null) || !"".equals(ccrecipient)) {
                client.addRecipient(ccrecipient);
                header.addCC(ccrecipient);
            }

            //Sends SMTP DATA command in preparation to send an email message.
            //Returns the writer to which the mesage is written.
            Writer writer = client.sendMessageData();

            if (writer != null) {
                //Write SMTP Header
                writer.write(header.toString());
                writer.write(message);
                writer.close();

                //finalize the transaction and verify its success
                //or failure from the server reply. 
                   boolean completion = client.completePendingCommand();

                if (completion) {
                    System.out.println("Mail sent successfully");
                }
            }

            client.logout();
            client.disconnect();
        } catch (IOException e) {
            if (client.isConnected()) {
                try {
                    client.disconnect();
                } catch (IOException f) {
                    // ignore
                }
            }

            e.printStackTrace();
        }
    }
}
