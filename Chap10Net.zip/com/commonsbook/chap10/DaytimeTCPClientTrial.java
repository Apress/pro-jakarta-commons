package com.commonsbook.chap10;
import org.apache.commons.net.*;

public class DaytimeTCPClientTrial {
    public static void main(String[] args) throws Exception {
        System.out.println("DayTime >>" + getDayTime("gnomon.cc.columbia.edu"));
    }

    public static String getDayTime(String host) throws Exception {
        DaytimeTCPClient client = new DaytimeTCPClient();

        // set timeout
        client.setDefaultTimeout(30000);
        client.connect(host);

        String dayTime = client.getTime().trim();
        client.disconnect();

        return dayTime;
    }
}
