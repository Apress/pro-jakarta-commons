package com.commonsbook.chap6;
import java.sql.*;

import javax.sql.*;

import org.apache.commons.dbcp.*;
import org.apache.commons.pool.*;
import org.apache.commons.pool.impl.*;

public class PoolingDriverDataSourceTrial {
    public static void main(String[] args) {
        Connection connUsingDriver = null;
        Connection connUsingDataSource = null;
        Statement stmt = null;
        ResultSet rset = null;

        try {
            //Load MySQL Driver
            Class.forName("com.mysql.jdbc.Driver");

            //URI for test database
            String uri = "jdbc:mysql://127.0.0.1:3306/test";

            //PoolingDriver Section
            registerPoolingDriver(uri);
            connUsingDriver = DriverManager.getConnection(
                    "jdbc:apache:commons:dbcp:test");
            System.out.println("[PoolingDriver] DB Name = " +
                connUsingDriver.getMetaData().getDatabaseProductName());

            //PoolingDataSource Section
            DataSource dataSrc = getPoolingDataSource(uri);
            connUsingDataSource = dataSrc.getConnection();
            System.out.println("[PoolingDataSource] DB Name = " +
                connUsingDataSource.getMetaData().getDatabaseProductName());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rset != null) {
                    rset.close();
                }

                if (stmt != null) {
                    stmt.close();
                }

                if (connUsingDriver != null) {
                    connUsingDriver.close();
                }

                if (connUsingDataSource != null) {
                    connUsingDataSource.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**Get a PoolingDataSource     */
    private static DataSource getPoolingDataSource(String uri)
        throws Exception {
        ObjectPool connPool = getConnPool(uri);
        DataSource dataSrc = new PoolingDataSource(connPool);

        return dataSrc;
    }

    /**Register a PoolingDriver     */
    private static void registerPoolingDriver(String uri)
        throws Exception {
        ObjectPool connPool = getConnPool(uri);
        PoolingDriver driver = new PoolingDriver();
        driver.registerPool("test", connPool);
    }

    /**Get Connection Pool     */
    private static ObjectPool getConnPool(String uri) throws Exception {
        ObjectPool connPool = new GenericObjectPool(null);
        ConnectionFactory connFactory = new DriverManagerConnectionFactory(uri,
                null);
        PoolableConnectionFactory poolableConnFactory = new PoolableConnectionFactory(connFactory,
                connPool, null, null, false, true);

        return connPool;
    }
}
