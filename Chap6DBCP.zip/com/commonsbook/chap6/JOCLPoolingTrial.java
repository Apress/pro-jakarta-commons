package com.commonsbook.chap6;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JOCLPoolingTrial {
    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rset = null;

        try {
            //jocltest is stated in the connection URI
            String uri = "jdbc:apache:commons:dbcp:/jocltest";

            //The qeury to be executed
            String query = "SELECT StudId, Name FROM student";

            //MySQL JDBC Driver
            Class.forName("com.mysql.jdbc.Driver");
            Class.forName("org.apache.commons.dbcp.PoolingDriver");

            conn = DriverManager.getConnection(uri);
            stmt = conn.createStatement();
            rset = stmt.executeQuery(query);

            while (rset.next()) {
                System.out.println(rset.getString(1) + "\t" +
                    rset.getString(2));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rset != null) {
                    rset.close();
                }

                if (stmt != null) {
                    stmt.close();
                }

                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
