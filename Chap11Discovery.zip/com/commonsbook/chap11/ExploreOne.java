package com.commonsbook.chap11;
public class ExploreOne implements Discoverable {
    public void explore() {
        System.out.println("Exploring One");
    }
}
