package com.commonsbook.chap11;
public class ExploreTwo implements Discoverable {
    public void explore() {
        System.out.println("Exploring Two");
    }
}
