package com.commonsbook.chap11;
import org.apache.commons.discovery.tools.DiscoverClass;

public class UseDiscovery {
    public static void main(String[] args) throws Exception {
        DiscoverClass discoverClass = new DiscoverClass();
        Class discovered = discoverClass.find(Discoverable.class);
        System.out.println("Class >>"+discovered);
        Discoverable disc = (Discoverable)discovered.newInstance();
        disc.explore();
    }
}
