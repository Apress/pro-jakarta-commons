package com.commonsbook.chap11;
public interface Discoverable {
    public void explore();
}

