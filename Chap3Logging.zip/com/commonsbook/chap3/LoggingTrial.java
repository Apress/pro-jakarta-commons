package com.commonsbook.chap3;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoggingTrial {
    public static void main(String[] args) {
        //Get new Log instance for this class.
        Log log = LogFactory.getLog(LoggingTrial.class);

        //Which Logger is being Used?
        System.out.println("The Log being used >>> " + log);

        //Create a dummy exception to depict exception logging
        Exception e = new Exception("A DUMMY EXCEPTION");

        //Log TRACE if enabled
        if (log.isTraceEnabled()) {
            log.trace("TRACE TEST");
            log.trace("TRACE TEST", e);
        }

        //Log DEBUG if enabled
        if (log.isDebugEnabled()) {
            log.debug("DEBUG TEST");
            log.debug("DEBUG TEST", e);
        }

        //Log INFO if enabled
        if (log.isInfoEnabled()) {
            log.info("INFO TEST");
            log.info("INFO TEST", e);
        }

        //Log WARN if enabled
        if (log.isWarnEnabled()) {
            log.warn("WARN TEST");
            log.warn("WARN TEST", e);
        }

        //Log ERROR if enabled
        if (log.isErrorEnabled()) {
            log.error("ERROR TEST");
            log.error("ERROR TEST", e);
        }

        //Log FATAL if enabled
        if (log.isFatalEnabled()) {
            log.fatal("FATAL TEST");
            log.fatal("FATAL TEST", e);
        }
    }
}
